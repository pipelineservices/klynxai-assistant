from __future__ import annotations
import os
import sqlite3
from typing import Optional, Dict, Any, List

DB_PATH = os.environ.get("INCIDENTS_DB_PATH", os.path.join(os.path.dirname(__file__), "data", "incidents.db"))

def _conn() -> sqlite3.Connection:
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    return sqlite3.connect(DB_PATH, check_same_thread=False)

def init_db() -> None:
    with _conn() as c:
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS incidents (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              incident_id TEXT,
              slack_channel TEXT,
              slack_ts TEXT,
              thread_ts TEXT,
              status TEXT DEFAULT 'open',
              severity TEXT,
              summary TEXT,
              cloud_provider TEXT,
              region TEXT,
              resources TEXT,
              analysis_text TEXT,
              created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
              updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
            """
        )
        c.execute("CREATE INDEX IF NOT EXISTS idx_thread ON incidents(thread_ts)")
        c.execute("CREATE INDEX IF NOT EXISTS idx_incident_id ON incidents(incident_id)")

def save_incident(
    incident_id: str,
    slack_channel: str,
    slack_ts: str,
    thread_ts: str,
    severity: str,
    summary: str,
    cloud_provider: str,
    region: Optional[str],
    resources: str,
    analysis_text: str = "",
    status: str = "open",
) -> None:
    with _conn() as c:
        c.execute(
            """
            INSERT INTO incidents (incident_id, slack_channel, slack_ts, thread_ts, status, severity, summary, cloud_provider, region, resources, analysis_text)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """
            ,
            (incident_id, slack_channel, slack_ts, thread_ts, status, severity, summary, cloud_provider, region, resources, analysis_text),
        )

def update_incident_status(thread_ts: str, status: str) -> None:
    with _conn() as c:
        c.execute(
            "UPDATE incidents SET status=?, updated_at=CURRENT_TIMESTAMP WHERE thread_ts=?",
            (status, thread_ts),
        )

def update_incident_analysis(thread_ts: str, analysis_text: str) -> None:
    with _conn() as c:
        c.execute(
            "UPDATE incidents SET analysis_text=?, updated_at=CURRENT_TIMESTAMP WHERE thread_ts=?",
            (analysis_text, thread_ts),
        )

def get_incident_by_thread_ts(thread_ts: str) -> Optional[Dict[str, Any]]:
    with _conn() as c:
        cur = c.execute(
            "SELECT incident_id, slack_channel, slack_ts, thread_ts, status, severity, summary, cloud_provider, region, resources, analysis_text, created_at, updated_at "
            "FROM incidents WHERE thread_ts=? ORDER BY id DESC LIMIT 1",
            (thread_ts,),
        )
        row = cur.fetchone()
        if not row:
            return None
        keys = ["incident_id","slack_channel","slack_ts","thread_ts","status","severity","summary","cloud_provider","region","resources","analysis_text","created_at","updated_at"]
        return dict(zip(keys, row))

def list_incidents(limit: int = 200) -> List[Dict[str, Any]]:
    with _conn() as c:
        cur = c.execute(
            "SELECT incident_id, slack_channel, thread_ts, status, severity, summary, cloud_provider, region, resources, created_at, updated_at "
            "FROM incidents ORDER BY id DESC LIMIT ?",
            (limit,),
        )
        rows = cur.fetchall()
        keys = ["incident_id","slack_channel","thread_ts","status","severity","summary","cloud_provider","region","resources","created_at","updated_at"]
        return [dict(zip(keys, r)) for r in rows]
