from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from slack_handler import slack_router
from otel_handler import otel_router
from ui_dashboard import ui_router
from history_repository import init_db

app = FastAPI(title="KLYNX AI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

init_db()

@app.get("/")
def root():
    return {"status": "KLYNX AI Backend running"}

app.include_router(slack_router)
app.include_router(otel_router)
app.include_router(ui_router)
