from __future__ import annotations

import os
import re
import aiohttp
from fastapi import APIRouter, Request
from slack_sdk.web.async_client import AsyncWebClient

from incident_engine import analyze_cloud_issue, format_incident_for_slack
from image_analyzer import extract_text_from_image_bytes
from auto_fix_engine import run_auto_fix
from history_repository import save_incident, get_incident_by_thread_ts, update_incident_status, update_incident_analysis
from models import Incident

SLACK_BOT_TOKEN = os.environ.get("SLACK_BOT_TOKEN", "")

slack_router = APIRouter()
client = AsyncWebClient(token=SLACK_BOT_TOKEN) if SLACK_BOT_TOKEN else None

YES_RE = re.compile(r"\b(yes|y|approve|ok|go ahead)\b", re.IGNORECASE)
NO_RE = re.compile(r"\b(no|n|deny|stop|cancel)\b", re.IGNORECASE)

async def _download_slack_file(url_private: str) -> bytes:
    if not SLACK_BOT_TOKEN:
        raise RuntimeError("SLACK_BOT_TOKEN not set")
    headers = {"Authorization": f"Bearer {SLACK_BOT_TOKEN}"}
    async with aiohttp.ClientSession() as session:
        async with session.get(url_private, headers=headers) as resp:
            if resp.status != 200:
                raise RuntimeError(f"Slack file download failed: HTTP {resp.status}")
            return await resp.read()

async def _maybe_ocr_first_image(event: dict) -> tuple[str, list[str]]:
    files = event.get("files") or []
    for f in files:
        mimetype = (f.get("mimetype") or "")
        url_private = f.get("url_private_download") or f.get("url_private")
        if url_private and mimetype.startswith("image/"):
            img_bytes = await _download_slack_file(url_private)
            text, warnings = extract_text_from_image_bytes(img_bytes)
            return text, warnings
    return "", []

def _is_bot_message(event: dict) -> bool:
    return bool(event.get("bot_id") or event.get("subtype") == "bot_message")

@slack_router.post("/api/slack/events")
async def handle_slack_events(request: Request):
    if client is None:
        return {"status": "error", "reason": "SLACK_BOT_TOKEN not configured"}

    body = await request.json()

    if "challenge" in body:
        return {"challenge": body["challenge"]}

    event = body.get("event", {})
    event_type = event.get("type")

    if event_type not in ("app_mention", "message"):
        return {"status": "ignored"}

    if _is_bot_message(event):
        return {"status": "ignored_bot"}

    channel = event.get("channel")
    ts = event.get("ts")
    thread_ts = event.get("thread_ts") or ts
    user_text = (event.get("text") or "").strip()

    # Approval flow for thread replies
    if event_type == "message" and event.get("thread_ts"):
        existing = get_incident_by_thread_ts(thread_ts)
        if not existing:
            return {"status": "ignored_no_incident"}

        if YES_RE.search(user_text or ""):
            update_incident_status(thread_ts, "approved")
            incident_stub = Incident(
                incident_id=existing["incident_id"],
                severity=existing["severity"],
                summary=existing["summary"],
                cloud_provider=existing["cloud_provider"],
                region=existing["region"],
                resources=[r for r in (existing.get("resources") or "").split(",") if r],
                raw_text=existing.get("analysis_text") or existing.get("summary") or "",
            )
            execute = os.environ.get("AUTO_FIX_EXECUTE", "false").lower() == "true"
            res = run_auto_fix(incident_stub, approve=True, dry_run_default=(not execute))

            msg = "✅ *Auto-fix execution result*\n"
            msg += f"- Approved: `true`\n- Dry-run: `{res.dry_run}`\n"
            if res.actions:
                msg += "\n*Actions:*\n" + "\n".join(f"- {a}" for a in res.actions)
            if res.errors:
                msg += "\n\n*Errors:*\n" + "\n".join(f"- {e}" for e in res.errors)
            if res.notes:
                msg += "\n\n*Notes:*\n" + "\n".join(f"- {n}" for n in res.notes)

            await client.chat_postMessage(channel=channel, thread_ts=thread_ts, text=msg)
            return {"status": "ok"}

        if NO_RE.search(user_text or ""):
            update_incident_status(thread_ts, "denied")
            await client.chat_postMessage(channel=channel, thread_ts=thread_ts, text="🛑 Auto-fix denied. I will not take any action.")
            return {"status": "ok"}

        return {"status": "ignored_thread_message"}

    # app_mention -> analyze (including OCR)
    ocr_text, warnings = await _maybe_ocr_first_image(event)
    combined = user_text
    if ocr_text:
        combined = (combined + "\n\n[OCR_FROM_IMAGE]\n" + ocr_text).strip()

    incident = analyze_cloud_issue(combined)
    analysis_text = format_incident_for_slack(incident)
    if warnings:
        analysis_text += "\n\n*Image/OCR warnings:*\n" + "\n".join(f"- {w}" for w in warnings)

    save_incident(
        incident_id=incident.incident_id,
        slack_channel=channel,
        slack_ts=ts,
        thread_ts=thread_ts,
        severity=incident.severity,
        summary=incident.summary,
        cloud_provider=incident.cloud_provider,
        region=incident.region,
        resources=",".join(incident.resources) if incident.resources else "",
        analysis_text=analysis_text,
        status="open",
    )

    final_msg = analysis_text + "\n\n*Should I apply the fix automatically?* Reply in this thread with `yes` or `no`."
    await client.chat_postMessage(channel=channel, thread_ts=thread_ts, text=final_msg)
    update_incident_analysis(thread_ts, analysis_text)

    return {"status": "ok"}
